// fake qpixmap.h

