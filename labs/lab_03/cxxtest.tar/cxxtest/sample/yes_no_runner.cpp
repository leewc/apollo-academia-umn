//
// A sample program that uses class YesNoRunner to run all the tests
// and find out if all pass.
//

#include <cxxtest/YesNoRunner.h>

int main() {
    return CxxTest::YesNoRunner().run();
}
